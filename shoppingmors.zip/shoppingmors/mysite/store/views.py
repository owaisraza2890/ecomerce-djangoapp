from django.shortcuts import render
from .models import *
from django.http import JsonResponse
import json
from math import ceil
# Create your views here.


def store(request):
    # products = Product.objects.all()
    # n = len(products)
    # nSlides = n//4 + ceil((n/4)-(n//4))
    # context = {'no_of_slides': nSlides, 'range': range(
    #     1, nSlides), 'product': products}
    # allprodut = [[products, range(1, nSlides), nSlides], [
    #     products, range(1, nSlides), nSlides]]
    allproduct = []
    catprodts = Product.objects.values('catagory', 'id')
    cats = {item["catagory"] for item in catprodts}
    for cat in cats:
        prod = Product.objects.filter(catagory=cat)
        n = len(prod)
        nslides = n//4 + ceil((n/4) - (n//4))
        allproduct.append([prod, range(1, nslides), nslides])
    context = {'allproduct': allproduct}
    return render(request, 'store/store.html', context)


def productView(request, id):
    product = Product.objects.filter(id=id)

    return render(request, "store/productView.html", {'product': product[0]})


def cart(request):
    if request.user.is_authenticated:
        customer = request.user.customer
        order, created = Order.objects.get_or_create(
            customer=customer, complete=False)
        items = order.orderitem_set.all()
    else:
        items = []
        order = {'get_cart_total': 0, 'get_cart_item': 0}
    context = {'items': items, 'order': order}
    return render(request, 'store/cart.html', context)


def checkout(request):
    if request.user.is_authenticated:
        customer = request.user.customer
        order, created = Order.objects.get_or_create(
            customer=customer, complete=False)
        items = order.orderitem_set.all()
    else:
        items = []
        order = {'get_cart_total': 0, 'get_cart_item': 0}
    context = {'items': items, 'order': order}
    return render(request, 'store/checkout.html', context)


def updateItem(request):
    print("owais")
    # data = json.loads(request.data)
    # productId = data['productId']
    # action = data['action']

    # print("Action:", action)
    # print("productId:", productId)

    # customer = request.user.customer
    # product = Product.objects.get(id=productId)
    # order, created = Order.objects.get_or_create(
    #     customer=customer, complete=False)
    # orderItem, created = OrderItem.objects.get_or_create(
    #     order=order, product=product)

    # if action == 'add':
    #     orderItem.quantity = (orderItem.quantity + 1)
    # elif action == 'remove':
    #     orderItem.quantity = (orderItem.quantity - 1)

    # orderItem.save()

    # if orderItem.quantity <= 0:
    #     orderItem.delete()
    return JsonResponse('Item was added', safe=False)


def contactus(request):
    if request.method == "POST":
        name = request.POST.get('name', '')
        email = request.POST.get('email', '')
        phone = request.POST.get('phone', '')
        desc = request.POST.get('desc', '')
        contactus = Contactus(name=name, email=email, phone=phone, desc=desc)
        contactus.save()
    return render(request, 'store/contactus.html')
